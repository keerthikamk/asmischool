

			<?php $__env->startSection('title','Specialties'); ?>
			<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="page-header__bg " style="background-image: url(/assets/images/backgrounds/s1.jpg);" ></div>
    <!-- /.page-header__bg -->
    <div class="container">
        <h2 class="page-header__title">Specialties</h2>
        <ul class="kidearn-breadcrumb list-unstyled">
            <li><a href="/">Home</a></li>
            <li><span>Our Specialties</span></li>
        </ul><!-- /.thm-breadcrumb list-unstyled -->
    </div><!-- /.container -->
</section><!-- /.page-header -->

<section class="blog-one blog-one--page">
	<div class="container">
		<div class="row gutter-y-30">
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-1.png" alt="10 Easy steps to more learn about play">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <a href="#" class=""><span class="sr-only">Air Purified Class Rooms with A/C</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
        <div class="blog-card__content__top">
     
        </div><!-- /.blog-card__content__top -->
        <h3 class="blog-card__title"><a href="#">Air Purified Class Rooms with A/C</a></h3><!-- /.blog-card__title -->

       
    </div><!-- /.blog-card__content -->
</div><!-- /.blog-card -->


			</div><!-- /.col-md-6 col-lg-4 -->

            
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-2.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <a href="#" class=""><span class="sr-only">High Safe and Eco-Friendly Environment</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">High Safe and Eco-Friendly Environment</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-3.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <a href="#" class=""><span class="sr-only">Miniature Models & Building Blocks - Non –Toxic Play Materials</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Miniature Models & Building Blocks - Non –Toxic Play Materials</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-4.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <a href="#" class=""><span class="sr-only">Child Safe Infrastructure</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Child Safe Infrastructure</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-5.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-5.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-5.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-5.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-5.png);"></div>
        <a href="#" class=""><span class="sr-only">Security and Individual Attention</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Security and Individual Attention</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->


                
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-6.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <a href="#" class=""><span class="sr-only">Competitions and club Activities</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Competitions and club Activities</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-2.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <a href="#" class=""><span class="sr-only">Audio-Visual Room & Indian Play Lab</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Audio-Visual Room & Indian Play Lab</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-2.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <a href="#" class=""><span class="sr-only">Competitions and club Activities</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Competitions and club Activities</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-3.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <a href="#" class=""><span class="sr-only">Montessori Activities &Fun Class Rooms</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Montessori Activities &Fun Class Rooms</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->


			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-6.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <a href="#" class=""><span class="sr-only">Kids Library, Garden & Outdoor Play Area</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Kids Library, Garden & Outdoor Play Area</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-2.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-2.png);"></div>
        <a href="#" class=""><span class="sr-only">Qualified & Well-Trained Staff</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Qualified & Well-Trained Staff</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-6.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-6.png);"></div>
        <a href="#" class=""><span class="sr-only">Comfortable Bedding for Daycare Kids</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Comfortable Bedding for Daycare Kids</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-4.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-4.png);"></div>
        <a href="#" class=""><span class="sr-only">Parents-Teacher’s co-ordination</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Parents-Teacher’s co-ordination</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->
			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-1.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <a href="#" class=""><span class="sr-only">Parents-Teacher’s co-ordination</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Parents-Teacher’s co-ordination</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->
			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-3.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <a href="#" class=""><span class="sr-only">Field Trips & Special Days</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Field Trips & Special Days</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->
			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-3.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-3.png);"></div>
        <a href="#" class=""><span class="sr-only">Intellectual Development & Speech Therapy Centre</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Intellectual Development & Speech Therapy Centre</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			
			
			<div class="col-md-6 col-lg-4">
				<div class="blog-card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='100ms' style='--accent-color: #75C137;'>
    <div class="blog-card__image">
        <img src="assets/images/blog/blog-1-1.png" alt="That jerk from finance really threw me">
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <div class="blog-card__image__layer" style="background-image: url(assets/images/blog/blog-1-1.png);"></div>
        <a href="#" class=""><span class="sr-only">Transport facility</span>
            <!-- /.sr-only --></a>
    </div><!-- /.blog-card__image -->
    <div class="blog-card__content">
      
        <h3 class="blog-card__title"><a href="#">Transport facility</a></h3><!-- /.blog-card__title -->
        <div class="blog-card__content__bottom">
            <div class="blog-card__author">
   
            </div><!-- /.blog-card__author -->
       
                </a><!-- /.blog-card__link -->
            </div><!-- /.blog-card__content__bottom -->
        </div><!-- /.blog-card__content -->
        </div><!-- /.blog-card -->
                </div><!-- /.col-md-6 col-lg-4 -->

			
			


			


            
			
		</div><!-- /.row -->
	</div><!-- /.container -->
</section><!-- /.blog-one blog-one--page -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abish\A.S.M.I\school\resources\views\specialities.blade.php ENDPATH**/ ?>